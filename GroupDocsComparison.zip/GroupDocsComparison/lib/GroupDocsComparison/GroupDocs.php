<?php

include_once 'RavenGroupDocsUtil.php';

class GroupDocsComparison_GroupDocs {
	/**
	 * Table object
	 */
	protected $_config = null;

	/**
	 * GroupDocs result file ID
	 */
	protected $_resfileId = 0;
	
	/**
	 * GroupDocs user embd key
	 */
	protected $_embedKey = '';

	/**
	 * Html frame border
	 */
	protected $_frameborder = 0;

	/**
	 * Html frame width
	 */
	protected $_width = 0;

	/**
	 * Html frame height
	 */
	protected $_height = 0;

	/**
	 * Class constructor
	 * @param Array $config
	 */
	public function __construct($config = array()) {
        try {
            $this->_config = new GroupDocsComparison_Config();
            $confArray = json_decode($this->getConfig('data'), true);
            // Set Client ID
            $this->_cid = (empty($config['cid'])) ? $confArray['cid'] : $config['cid'];
            // Set Private key
            $this->_pkey = (empty($config['pkey'])) ? $confArray['pkey'] : $config['pkey'];
            // Set base URL
            $this->_baseurl = (empty($config['baseurl'])) ? $confArray['baseurl'] : $config['baseurl'];
            // Set first file ID
            $this->_firstfileId = (empty($config['firstfileId'])) ? $confArray['firstfileId'] : $config['firstfileId'];
            // Set second file ID
            $this->_secondfileId = (empty($config['secondfileId'])) ? $confArray['secondfileId'] : $config['secondfileId'];
            // Set result file ID
            $this->_resfileId = (empty($config['resfileId'])) ? $confArray['resfileId'] : $config['resfileId'];
            // Set embed key
            $this->_embedKey = (empty($config['embedKey'])) ? $confArray['embedKey'] : $config['embedKey'];
            // Set frameborder
            $this->_frameborder = (empty($config['frameborder'])) ? $this->getConfig('frameborder') : $config['frameborder'];
            // Set width
            $this->_width = (empty($config['width'])) ? $this->getConfig('width') : $config['width'];
            // Set height
            $this->_height = (empty($config['height'])) ? $this->getConfig('height') : $config['height'];
        }
        catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
        }
    }

	public function getConfig($key = null) {
		try {
			$rows = $this->_config->fetchAll();
            for ($n = 0; $n < count($rows); $n += 1) {
                if ($rows[$n]['id'] == 5) {
                    return $rows[$n][$key];
                }
            }
        } catch (Zend_Db_Exception $e) {
            Logger::error("Failed to get configuration; ".$e->getMessage());
            RavenGroupDocsUtil::captureException($e);
        }
        catch (Exception $e) {
            Logger::error("Failed to get configuration; ".$e->getMessage());
            RavenGroupDocsUtil::captureException($e);
        }
		return null;
	}

	public function setConfig($values = array()) {
		$this->_config->update($values, 'id = 5');
	}

	/**
	 * Render html frame
	 */
	public function renderFrame() {
        try {
            return '<iframe src="http://apps.groupdocs.com/document-comparison/embed/'
                    . $this->_embedKey
                    . '/'
                    . $this->_resfileId
                    . '?referer=PimCore-Comparison/1.0.0" frameborder="'
                    . $this->_frameborder
                    . '" width="'
                    . $this->_width
                    . '" height="'
                    . $this->_height
                    . '">If you can see this text, your browser does not support iframes. Please enable iframe support in your browser or use the latest version of any popular web browser such as Mozilla Firefox or Google Chrome. For more help, please check our documentation Wiki: <a href="http://groupdocs.com/docs/display/comparison/GroupDocs+Comparison+Integration+with+3rd+Party+Platforms">http://groupdocs.com/docs/display/comparison/GroupDocs+Comparison+Integration+with+3rd+Party+Platforms</a></iframe>';
        } catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
        }
        return '';
	}
}