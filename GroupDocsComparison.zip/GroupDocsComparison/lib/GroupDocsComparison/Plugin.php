<?php

include_once 'RavenGroupDocsUtil.php';

class GroupDocsComparison_Plugin extends Pimcore_API_Plugin_Abstract implements Pimcore_API_Plugin_Interface {

	public static function needsReloadAfterInstall() {
		return true;
	}

	public static function install() {
        try {
            Pimcore_API_Plugin_Abstract::getDb()->query("CREATE TABLE IF NOT EXISTS `groupdocs_comparison` (
                `id` INTEGER,
                `cid` varchar(256) DEFAULT '0',
                `pkey` varchar(256) DEFAULT '0',
                `baseurl` varchar(256) DEFAULT '0',
                `firstfileId` varchar(256) DEFAULT '0',
                `secondfileId` varchar(256) DEFAULT '0',
                `resfileId` varchar(256) DEFAULT '0',
                `embedKey` varchar(256) DEFAULT '0',
                `frameborder` INTEGER DEFAULT 0,
                `width` INTEGER DEFAULT 480,
                `height` INTEGER DEFAULT 320,
                    PRIMARY KEY  (`id`)
                    ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
            Pimcore_API_Plugin_Abstract::getDb()->query("INSERT INTO `groupdocs_comparison` (`id`, `cid`, `pkey`, `baseurl`, `firstfileId`, `secondfileId`, `resfileId`, `embedKey`, `frameborder`, `width`, `height`) VALUES (1, '', '', 'https://api.groupdocs.com/v2.0', '', '', '', '', 0, 480, 320);");

            if (self::isInstalled()) {
                return "GroupDocs Comparison Plugin successfully installed.";
            } else {
                return "GroupDocs Comparison Plugin could not be installed.";
            }
        } catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
        }
	}

	public static function uninstall() {
        try {
            Pimcore_API_Plugin_Abstract::getDb()->query("DROP TABLE `groupdocs_comparison`;");
            if (!self::isInstalled()) {
                return "GroupDocs Comparison Plugin successfully uninstalled.";
            } else {
                return "GroupDocs Comparison Plugin could not be uninstalled.";
            }
        } catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
        }
	}

	public static function isInstalled() {
        try {
            $result = null;
            $result = Pimcore_API_Plugin_Abstract::getDb()->query("SELECT * FROM `groupdocs_comparison` WHERE `id`=1;") or die ("Table 'groupdocs_comparison' don't exists!");
            return (!empty($result)) && count($result->fetchAll()) == 1;
        } catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
            return false;
        }
    }

	public static function getTranslationFile($language) {

	}

	public static function getInstallPath() {
		return PIMCORE_PLUGINS_PATH . "/GroupDocsComparison/install";
	}
}