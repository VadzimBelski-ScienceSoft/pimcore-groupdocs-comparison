<?php
class GroupDocsComparison_Plugin extends Pimcore_API_Plugin_Abstract implements Pimcore_API_Plugin_Interface {

	public static function needsReloadAfterInstall() {
		return true;
	}

	public static function install() {
        try {
            Pimcore_API_Plugin_Abstract::getDb()->query("CREATE TABLE IF NOT EXISTS `plugin_groupdocs` (
                `id` INTEGER,
                `data` varchar(512) DEFAULT '0',
                `frameborder` INTEGER DEFAULT 0,
                `width` INTEGER DEFAULT 480,
                `height` INTEGER DEFAULT 320,
                    PRIMARY KEY  (`id`)
                    ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
            Pimcore_API_Plugin_Abstract::getDb()->query("INSERT INTO `plugin_groupdocs` (`id`, `data`, `frameborder`, `width`, `height`) VALUES (5, '{\"cid\":\"\",\"pkey\":\"\",\"baseurl\":\"https://api.groupdocs.com/v2.0\",\"firstfileId\":\"\",\"secondfileId\":\"\",\"resfileId\":\"\",\"embedKey\":\"\"}', 0, 480, 320);");

            if (self::isInstalled()) {
                return "GroupDocs Comparison Plugin successfully installed.";
            } else {
                return "GroupDocs Comparison Plugin could not be installed.";
            }
        }
        catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
        }
	}

	public static function uninstall() {
        try {
            if (count(Pimcore_API_Plugin_Abstract::getDb()->query("SELECT * FROM `plugin_groupdocs`;")->fetchAll()) == 1) {
                Pimcore_API_Plugin_Abstract::getDb()->query("DROP TABLE `plugin_groupdocs`;");
            }
            else {
                Pimcore_API_Plugin_Abstract::getDb()->query("DELETE FROM `plugin_groupdocs` WHERE `id`=5;");
            }
            if (!self::isInstalled()) {
                return "GroupDocs Comparison Plugin successfully uninstalled.";
            } else {
                return "GroupDocs Comparison Plugin could not be uninstalled.";
            }
        }
        catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
        }
	}

	public static function isInstalled() {
        try {
            $result = null;
            $result = Pimcore_API_Plugin_Abstract::getDb()->query("SELECT * FROM `plugin_groupdocs` WHERE `id`=5;") or die ("Table 'plugin_groupdocs' don't exists!");
            return (!empty($result)) && count($result->fetchAll()) == 1;
        }
        catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
        }
    }

	public static function getTranslationFile($language) {

	}

	public static function getInstallPath() {
		return PIMCORE_PLUGINS_PATH . "/GroupDocsComparison/install";
	}
}