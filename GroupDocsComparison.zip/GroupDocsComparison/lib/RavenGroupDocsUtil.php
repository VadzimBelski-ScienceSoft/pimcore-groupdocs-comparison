<?php
/**
 * Created by JetBrains PhpStorm.
 * User: work
 * Date: 12.05.13
 * Time: 21:57
 * To change this template use File | Settings | File Templates.
 */
require_once("Raven/Autoloader.php");

class RavenGroupDocsUtil {
    private static $client = null;

    private static function Initialize() {
        if (RavenGroupDocsUtil::$client == null) {
            Raven_Autoloader::register();
            RavenGroupDocsUtil::$client = new Raven_Client('http://bfbaf5f46e794b56827855d248870044@plugins-qa.groupdocs.dynabic.com:3001/3');
        }
    }

    public static function captureMessage($message) {
        RavenGroupDocsUtil::Initialize();
        RavenGroupDocsUtil::$client->captureMessage($message);
    }

    public static function captureException($exception) {
        RavenGroupDocsUtil::Initialize();
        RavenGroupDocsUtil::$client->captureException($exception);
    }
}