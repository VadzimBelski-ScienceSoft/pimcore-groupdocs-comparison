<?php

include_once 'GroupDocsComparison/groupdocs-php/APIClient.php';
include_once 'GroupDocsComparison/groupdocs-php/GroupDocsRequestSigner.php';
include_once 'GroupDocsComparison/groupdocs-php/MgmtApi.php';
include_once 'GroupDocsComparison/groupdocs-php/ComparisonApi.php';
include_once 'GroupDocsComparison/groupdocs-php/AsyncApi.php';
include_once 'GroupDocsComparison/groupdocs-php/SharedApi.php';

class GroupDocsComparison_GroupDocsComparisonAdminController extends Pimcore_Controller_Action_Admin {
	/**
	 * Return current values as json
	 */
	public function loaddataAction(){
        try{
            $this->_helper->viewRenderer->setNoRender();
            $conf = new GroupDocsComparison_GroupDocs();
            $this->_helper->json(array(
                'status' => 'ok',
                'id' => '5',
                'cid' => $conf->getConfig('cid'),
                'pkey' => $conf->getConfig('pkey'),
                'baseurl' => $conf->getConfig('baseurl'),
                'firstfileId' => $conf->getConfig('firstfileId'),
                'secondfileId' => $conf->getConfig('secondfileId'),
                'resfileId' => $conf->getConfig('resfileId'),
                'embedKey' => $conf->getConfig('embedKey'),
                'frameborder' => $conf->getConfig('frameborder'),
                'width' => $conf->getConfig('width'),
                'height' => $conf->getConfig('height')
            ));
        }
        catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
            $this->_helper->json(array('status' => 'error', 'message' => 'Load error: ' . $e->getMessage() ));
        }
	}

	/**
	 * Save new values
	 */
	public function savedataAction(){
        $this->getResponse()->setHttpResponseCode(200);
        error_reporting(E_ERROR | E_PARSE);
        $this->_helper->viewRenderer->setNoRender();
        try {
            $conf = new GroupDocsComparison_GroupDocs();

            $cid = $this->_getParam("cid");
            $pkey = $this->_getParam("pkey");
            $baseurl = $this->_getParam("baseurl");
            $firstfileId = $this->_getParam("firstfileId");
            $secondfileId = $this->_getParam("secondfileId");
            $frameborder = $this->_getParam("frameborder");
            $width = $this->_getParam("width");
            $height = $this->_getParam("height");

            if (strpos($cid, "@") != false) {
                $username = $cid;
                $password = $pkey;
                $groupDocsRequestSigner = new GroupDocsRequestSigner("12345");
                $apiClient = new APIClient($groupDocsRequestSigner);
                $sharedApi = new SharedApi($apiClient);
                $result = $sharedApi->LoginUser($username, $password);
                if ($result->status != 'Ok'){
                    $this->_helper->json(array('status' => 'error', 'message' => 'Save error: ' . $result->error_message ));
                    return;
                }
                $pkey = $result->result->user->pkey;
                $cid = $result->result->user->guid;
            }

            if ($frameborder != '' && $width != '' && $height != '') {

                $groupDocsRequestSigner = new GroupDocsRequestSigner($pkey);
                $apiClient = new APIClient($groupDocsRequestSigner);
                // Get embed key
                $area = 'comparison';
                $mgmtApi = new MgmtApi($apiClient);
                $oldKey = $mgmtApi->GetUserEmbedKey($cid, $area);
                if ($oldKey->status != 'Ok'){
                    $this->_helper->json(array('status' => 'error', 'message' => 'Save error: ' . $oldKey->error_message ));
                    return;
                }
                $embedKey = $oldKey->result->key->guid;
                if ($embedKey == '') {
                    $newKey = $mgmtApi->GenerateKeyForUser($cid, $area);
                    if ($newKey->status != 'Ok') {
                        $this->_helper->json(array('status' => 'error', 'message' => 'Save error: ' . $newKey->error_message ));
                        return;
                    }
                    $embedKey = $newKey->result->key->guid;
                }

                $comparisonApi = new ComparisonApi($apiClient);
                $compare = $comparisonApi->Compare($cid, $firstfileId, $secondfileId, '');
                if ($compare->status != 'Ok'){
                    $this->_helper->json(array('status' => 'error', 'message' => 'Save error: ' . $compare->error_message ));
                    return;
                }
                $jobId = $compare->result->job_id;

                // Get result document id
                $asyncApi = new AsyncApi($apiClient);
                do {
                    sleep(3);
                    $jobInfo = $asyncApi->GetJobDocuments($cid, $jobId);
                    if ($jobInfo->result->job_status == 'Postponed'){
                        $this->_helper->json(array('status' => 'error', 'message' => 'Save error (GetJobDocuments job status == Postponed): ' . $jobInfo->error_message ));
                        return;
                    }
                }
                while ($jobInfo->result->job_status != 'Completed' && $jobInfo->result->job_status != 'Archived');

                $resfileId = $jobInfo->result->outputs[0]->guid;

                $conf->setConfig(array(
                        'cid' => $cid,
                        'pkey' => $pkey,
                        'baseurl' => $baseurl,
                        'firstfileId' => $firstfileId,
                        'secondfileId' => $secondfileId,
                        'resfileId' => $resfileId,
                        'embedKey' => $embedKey,
                        'frameborder' => $frameborder,
                        'width' => $width,
                        'height' => $height
                    )
                );
            } else {
                $this->_helper->json(array('status' => 'error', 'message' => 'Save error: Invalid data' ));
            }
        } catch (Exception $e) {
            RavenGroupDocsUtil::captureException($e);
            $this->_helper->json(array('status' => 'error', 'message' => 'Save error: ' . $e->getMessage() ));
            return;
        }
	}
}