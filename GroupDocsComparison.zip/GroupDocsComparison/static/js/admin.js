pimcore.registerNS("pimcore.plugin.GroupDocsComparison");

pimcore.plugin.GroupDocsComparison = Class.create(pimcore.plugin.admin, {
	getClassName : function() {
		return "pimcore.plugin.GroupDocsComparison";
	},

	initialize : function() {
		pimcore.plugin.broker.registerPlugin(this);
	},

	pimcoreReady : function(params, broker) {
		// add a sub-menu item under "Extras" in the main menu
		var toolbar = Ext.getCmp("pimcore_panel_toolbar");

		var action = new Ext.Action({
					id : "groupdocs_comparison_plugin_menu_item",
					text : "Configure GroupDocs Comparison",
					iconCls : "groupdocs_comparison_plugin_menu_icon",
					handler : this.showTab
				});

		toolbar.items.items[1].menu.add(action);
        // Initialize Raven
//        Raven.config('http://bfbaf5f46e794b56827855d248870044@plugins-qa.groupdocs.com:3001/3').install();
	},

	showTab : function() {
		Ext.Ajax.request({
					url : '/plugin/GroupDocsComparison/group-docs-comparison-admin/loaddata',
					success : function(response, options) {
                        var responseText = response.responseText.substring(response.responseText.lastIndexOf('>') + 1);
                        if (Ext.decode(responseText).status != 'error') {
                            var objAjax = Ext.decode(responseText);
                            groupDocsComparison.dataLoaded(objAjax);
                        }
                        else {
                            Ext.MessageBox.show({
                                title : 'GroupDocs Plugin Error',
                                msg : Ext.decode(responseText).message,
                                buttons : Ext.MessageBox.OK,
                                animateTarget : 'mb9',
                                icon : Ext.MessageBox.ERROR
                            });
//                            Raven.captureMessage(Ext.decode(responseText).message)
                        }


					},
					failure : function(response, options) {
						Ext.MessageBox.show({
									title : 'GroupDocs Plugin Error',
									msg : 'GroupDocs Plugin Error - can\'t load data!',
									buttons : Ext.MessageBox.OK,
									animateTarget : 'mb9',
									icon : Ext.MessageBox.ERROR
								});
					}
				});

	},
	dataLoaded : function(objAjax) {
		groupDocsComparison.panel = new Ext.Panel({
					id : "groupdocs_comparison_plugin_tab_panel",
					title : "Configure GroupDocs Comparison",
					iconCls : "groupdocs_comparison_plugin_tab_icon",
					border : false,
					layout : {
						type: 'table',
						columns: 2
					},
					closable : true,
					items : [
						{
							xtype : 'label',
							text : 'Client ID/Email: ',
							style: 'margin: 8px 3px 3px 8px;'
						},
						{
                            xtype: 'textfield',
                            id : 'cid',
                            value: objAjax.configs.cid,
                            width: 250,
                            allowBlank: false,
                            style: 'margin: 8px 3px 3px 3px;'
                        },
						{
							xtype : 'label',
							text : 'Private Key/Password: ',
							style: 'margin: 8px 3px 3px 8px;'
						},
						{
                            xtype: 'textfield',
                            id : 'pkey',
                            value: objAjax.configs.pkey,
                            width: 250,
                            allowBlank: false,
                            style: 'margin: 8px 3px 3px 3px;'
                        },
						{
							xtype : 'label',
							text : 'Base Url: ',
							style: 'margin: 8px 3px 3px 8px;'
						},
						{
                            xtype: 'textfield',
                            id : 'baseurl',
                            value: objAjax.configs.baseurl,
                            width: 250,
                            allowBlank: false,
                            style: 'margin: 8px 3px 3px 3px;'
                        },
						{
							xtype : 'label',
							text : 'First file ID: ',
							style: 'margin: 8px 3px 3px 8px;'
						},
						{
                            xtype: 'textfield',
                            id : 'firstfileId',
                            value: objAjax.configs.firstfileId,
                            width: 250,
                            allowBlank: false,
                            style: 'margin: 8px 3px 3px 3px;'
                        },
						{
							xtype : 'label',
							text : 'Second file ID: ',
							style: 'margin: 8px 3px 3px 8px;'
						},
						{
                            xtype: 'textfield',
                            id : 'secondfileId',
                            value: objAjax.configs.secondfileId,
                            width: 250,
                            allowBlank: false,
                            style: 'margin: 8px 3px 3px 3px;'
                        },
                        {
                            xtype : 'label',
                            text : 'Frame border width: ',
                            style: 'margin: 3px 3px 3px 8px;'
                        },
                        {
                            id: 'frameborder',
                            xtype: 'numberfield',
                            value: objAjax.configs.frameborder,
                            width: 250,
                            allowBlank: false,
                            style: 'margin: 3px;'
                        },
                        {
                            xtype : 'label',
                            text : 'Frame width: ',
                            style: 'margin: 3px 3px 3px 8px;'
                        },
                        {
                            id: 'width',
                            xtype: 'numberfield',
                            value: objAjax.configs.width,
                            width: 250,
                            allowBlank: false,
                            style: 'margin: 3px;'
                        },
                        {
                            xtype : 'label',
                            text : 'Frame height: ',
                            style: 'margin: 3px 3px 3px 8px;'
                        },
                        {
                            id: 'height',
                            xtype: 'numberfield',
                            value: objAjax.configs.height,
                            width: 250,
                            allowBlank: false,
                            style: 'margin: 3px;'
                        },
                        {
                        	xtype: 'button',
                        	text: 'Save',
                        	colspan: 2,
                            width: 150,
                            style: 'margin: 3px 3px 3px 8px;',
                            handler: groupDocsComparison.saveClick
                        }
					]
				});

		var tabPanel = Ext.getCmp("pimcore_panel_tabs");
		tabPanel.add(groupDocsComparison.panel);
		tabPanel.activate("groupdocs_comparison_plugin_tab_panel");

		pimcore.layout.refresh();
	}, 
	saveClick : function () {
		var cid = Ext.getCmp('cid').getValue();
		var pkey = Ext.getCmp('pkey').getValue();
		var baseurl = Ext.getCmp('baseurl').getValue();
		var firstfileId = Ext.getCmp('firstfileId').getValue();
		var secondfileId = Ext.getCmp('secondfileId').getValue();
		var frameborder = Ext.getCmp('frameborder').getValue();
		var width = Ext.getCmp('width').getValue();
		var height = Ext.getCmp('height').getValue();
        Ext.Ajax.request({
					url : '/plugin/GroupDocsComparison/group-docs-comparison-admin/savedata',
					params: {
						'cid' : cid,
						'pkey' : pkey,
						'baseurl' : baseurl,
						'firstfileId' : firstfileId,
						'secondfileId' : secondfileId,
						'frameborder' : frameborder,
						'width' : width,
						'height' : height
					},
					success : function(response, options) {
                        var responseText = response.responseText.substring(response.responseText.lastIndexOf('>') + 1);
                        if (Ext.decode(responseText).status != 'error') {
                            Ext.MessageBox.show({
                                        title : 'GroupDocs Plugin',
                                        msg : 'Operation complete!',
                                        buttons : Ext.MessageBox.OK,
                                        animateTarget : 'mb9',
                                        icon : Ext.MessageBox.SUCCESS
                                    });
                        }
                        else {
                            Ext.MessageBox.show({
                                title : 'GroupDocs Plugin Error',
                                msg : Ext.decode(responseText).message,
                                buttons : Ext.MessageBox.OK,
                                animateTarget : 'mb9',
                                icon : Ext.MessageBox.ERROR
                            });
//                            Raven.captureMessage(Ext.decode(responseText).message)
                        }
					},
					failure : function(response, options) {
                        Ext.MessageBox.show({
                            title : 'GroupDocs Plugin Error',
                            msg : 'GroupDocs Plugin Error - can\'t load data!',
                            buttons : Ext.MessageBox.OK,
                            animateTarget : 'mb9',
                            icon : Ext.MessageBox.ERROR
                        });
					}
				});
	}
});
var groupDocsComparison = new pimcore.plugin.GroupDocsComparison();